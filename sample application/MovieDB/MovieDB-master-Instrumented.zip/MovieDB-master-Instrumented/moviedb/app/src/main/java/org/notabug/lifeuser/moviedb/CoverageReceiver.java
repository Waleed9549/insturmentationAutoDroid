package org.notabug.lifeuser.moviedb;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import java.io.File;
import java.lang.reflect.Method;

public class CoverageReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO: This method is called when the BroadcastReceiver is receiving
        // an Intent broadcast.
        if("com.context.FINISH_TESTING".equals(intent.getAction())){
            String coverageFilePath = "/mnt/sdcard/<USE APP DIRECTORY NAME>/coverage.ec";
            File coverageFile = new File(coverageFilePath);
            try {
                Class<?> emmaRTClass = Class.forName("com.vladium.emma.rt.RT");
                Method dumpCoverageMethod = emmaRTClass.getMethod("dumpCoverageData",coverageFile.getClass(),boolean.class,boolean.class);
                dumpCoverageMethod.invoke(null, coverageFile,true,false);
                Toast.makeText(context,"File created",Toast.LENGTH_SHORT).show();
            }
            catch (Exception e) {
                Toast.makeText(context,"File not created",Toast.LENGTH_SHORT).show();
                Toast.makeText(context, e.getCause().toString(), Toast.LENGTH_LONG).show();
            }
        }

    }
}